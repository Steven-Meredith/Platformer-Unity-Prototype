using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Melee<T> : MonoBehaviour where T : MonoBehaviour 
{
    // Start is called before the first frame update
    void Start()
    {
        Declare();
    }

    // Update is called once per frame

    void Declare()
    {
        Debug.Log("Hello I am a " + typeof(T));

        if (!this.gameObject.name.Contains("copy"))
        {

            GameObject copy = new GameObject();
            copy.name = "copy of a" + typeof(T);

            copy.AddComponent<T>();
        }
    }
}
