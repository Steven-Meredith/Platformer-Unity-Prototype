using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public GameObject player;
    public Transform respawnPoint;
    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.name == "Character")
        {
            Health.Instance.Lives -= 1;
            player.transform.position = respawnPoint.position;
        }

       
    }
}