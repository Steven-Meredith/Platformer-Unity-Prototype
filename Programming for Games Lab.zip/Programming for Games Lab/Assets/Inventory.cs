using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    [SerializeField] private List<Item> items = new List<Item>();
    void Start()
    {
        items.Add(new Armour(1));
        items.Add(new Armour(2));
        items.Add(new Weapons(2));
        items.Add(new Weapons(3));
        List<Item> weapon = (GetItemsByItemType<Weapons>());
        Debug.Log("Hey");

        
    }
    private List<Item> GetItemsByItemType<T>() where T : Item

    {
        List<Item> itemsToReturn = new List<Item>();
        for (int i = 0; i < items.Count; i++)
        {
            if (items[i] is T)
            {
                itemsToReturn.Add(items[i]);
            }
           
      
        }
        return itemsToReturn;
    }  
}
