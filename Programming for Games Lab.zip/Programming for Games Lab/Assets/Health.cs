using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Health : MonoBehaviour
{
    public static Health Instance;

    public HPBar healthBar;

    public int currentHealth;

    public int Lives = 3;

    public int lives
    {
        get
        {
            return Lives;
        }

        set
        {
            lives = value;
        }
            
    }

    public string DisplayHPPercentage
    {
        get
        {
            string HP = lives.ToString() + "%";
            return HP;
        }
    }

  

    void Start()

    {
        Debug.Log(DisplayHPPercentage);
        currentHealth = Lives;
        healthBar.SetMaxHealth(Lives);
    }

    private void Update()
    {
        if (Lives < 0)
        {
            Destroy(gameObject);
        }
    }

    public void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            DontDestroyOnLoad(gameObject);
            Instance = this;
        }
        
    }
}