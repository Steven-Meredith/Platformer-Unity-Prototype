using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class CollectingCoins : MonoBehaviour //IDataPersistence
{
    public TextMeshProUGUI collectingCoins;
    public int coins;
    
        public void Awake()
    {
       collectingCoins = this.GetComponent<TextMeshProUGUI>();
    }

    public void LoadData(GameData data)
    {
        this.coins = data.collectingCoins;
    }

    public void SavaData(ref GameData data)
    {
        data.collectingCoins = this.coins;
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void OnTriggerEnter(Collider Col)
    {

        if (Col.gameObject.tag == "Coin")
        {

            Debug.Log("Coin Collected!");
            
            //Col.gameObject.SetActive(false);
            Destroy(Col.gameObject);
        }
    }

    // Update is called once per frame
    
}
