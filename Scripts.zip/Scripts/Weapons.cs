using UnityEngine;
public class Weapons : Item
{
    [SerializeField] int damage;
    public Weapons(int damage)
    {
        this.damage = damage;
    }
}
