using UnityEngine;
public class Armour : Item
{
    [SerializeField] private int defense;
    public Armour(int defense)
    {
        this.defense = defense;
    }
}
