using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class HPBoost : MonoBehaviour
{
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.name == "Character")
        {
            Health.Instance.Lives += 5;
            Destroy(gameObject);
        }
    }
}
